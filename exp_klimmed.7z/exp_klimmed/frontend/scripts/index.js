import { getItems, createItem, deleteItem } from "./api.js";

const inputSurname = document.querySelector(".inputSurname");
const inputName = document.querySelector(".inputName");
const inputAge = document.querySelector(".inputAge");

const submitBtn = document.querySelector(".submitBtn");
submitBtn.textContent = "+"
const itemsEl = document.querySelector(".items");

let main = document.querySelector(".main")

async function updateItems() {
    let items = await getItems();

    let itemContainer = itemsEl.querySelector(".itemsContainer");
    if (itemContainer) {
        itemContainer.remove()
    }

    const newItemContainer = document.createElement("div");
    newItemContainer.className = "itemsContainer";

    for (const item of items) {
        const itemDiv = document.createElement("div");
        itemDiv.className = "item";

        let itemSurname = document.createElement("span");
        let itemName = document.createElement("span");
        let itemAge = document.createElement("span");
        itemSurname.textContent = item.surname;
        itemName.textContent = item.name;
        itemAge.textContent = item.age;

        const itemDeleteBtn = document.createElement("button");
        itemDeleteBtn.innerText = "-"
        itemDeleteBtn.classList.add("btn-del")
        itemDeleteBtn.addEventListener("click", () => {
            deleteItem(item.id).then(() => updateItems());
        });

        itemDiv.append(itemSurname, itemName, itemAge, itemDeleteBtn)
        newItemContainer.append(itemDiv)
        itemsEl.append(newItemContainer);
    }
}

submitBtn.addEventListener("click", async() => {
    const surname = inputSurname.value
    const name = inputName.value;
    const age = inputAge.value;
    if (!surname || !name || !age) return;
    if (+age >= 100) return;

    if (surname.length > 19 || name.length > 19) return;
    await createItem(surname, name, age)
    await updateItems()


    inputSurname.value = ""
    inputName.value = ""
    inputAge.value = ""
})

updateItems();