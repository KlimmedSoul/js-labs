import mysql from "mysql";

export const connection = mysql.createConnection({
    host: "127.0.0.1",
    user: "root",
    password: "klimmed",
    database: "klim_exp",
});

connection.connect();
connection.query("CREATE TABLE IF NOT EXISTS `items` (id INT PRIMARY KEY AUTO_INCREMENT, surname VARCHAR(20), name VARCHAR(20), age INT);", (err) => {
    if (err) throw err;
});