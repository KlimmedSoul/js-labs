import { connection } from "../database.js";

export default (req, res) => {
    if (req.body === undefined) return res.json({ error: "No body provided" });
    if (req.body.surname === undefined)
        return res.json({ error: "No surname provided" });
    if (req.body.name === undefined)
        return res.json({ error: "No name provided" });
    if (req.body.age === undefined)
        return res.json({ error: "No age provided" });

    connection.query(
        "INSERT INTO items (surname, name, age) VALUES (?, ?, ?);",
        [req.body.surname, req.body.name, req.body.age],
        (err, rows, fields) => {
            if (err) throw err;
            res.json({});
        }
    );
};
